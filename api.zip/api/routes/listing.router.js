import express from 'express';
import { createListing, deleteListing, updateListing, getListing, getListings } from '../controllers/listing.controller.js';
import { verifyToken } from '../utils/verifyUser.js';

const router = express.Router();

// Create a new listing
router.post('/create', verifyToken, createListing);

// Delete a listing
router.delete('/delete/:id', verifyToken, deleteListing);

// Update an existing listing (Changed to PUT for update)
router.put('/update/:id', verifyToken, updateListing);

// Get a single listing by id
router.get('/get/:id', getListing);

// Get all listings
router.get('/get', getListings);

export default router;
