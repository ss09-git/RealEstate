import express from 'express';
import Listing from '../models/listing.model.js';
import verifyToken from '../utils/verifyToken.js';
import verifyAdmin from '../utils/verifyAdmin.js';

const router = express.Router();

// Get all listings
router.get('/listings', verifyToken, verifyAdmin, async (req, res) => {
  try {
    const listings = await Listing.find();
    res.json(listings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Approve listing
router.put('/listings/:id/approve', verifyToken, verifyAdmin, async (req, res) => {
  try {
    const listing = await Listing.findByIdAndUpdate(req.params.id, { approved: true }, { new: true });
    res.json(listing);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Disapprove listing
router.put('/listings/:id/disapprove', verifyToken, verifyAdmin, async (req, res) => {
  try {
    const listing = await Listing.findByIdAndUpdate(req.params.id, { approved: false }, { new: true });
    res.json(listing);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router; // Default export for ES Modules
