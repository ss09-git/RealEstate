import express from 'express';
import mongoose from 'mongoose';
import userRouter from './routes/user.routes.js';
import authRouter from './routes/auth.route.js';
import listingRouter from './routes/listing.router.js';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import adminRoutes from './routes/admin.route.js'
import cors from 'cors';

dotenv.config();

// Connect to MongoDB
mongoose.connect('mongodb+srv://sohamdhavale2:g2cBtx8dwwjqnDQE@cluster0.wdfie.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
  .then(() => console.log('Connected to MongoDB!'))
  .catch((err) => console.log(err));

const app = express();

// Middleware
app.use(express.json());
app.use(cookieParser());
app.use(cors());  // Add CORS middleware

// Routes
app.use("/api/user", userRouter);
app.use("/api/auth", authRouter);
app.use("/api/listing", listingRouter); // Mount listing routes under /api/listing

// Error handling middleware
app.use((err, req, res, next) => {
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal server error';

  // Log the error stack in development mode
  if (process.env.NODE_ENV === 'development') {
    console.error(err.stack);
  }

  return res.status(statusCode).json({
    success: false,
    statusCode,
    message,
  });
});

app.listen(3000, () => {
  console.log('Listening on port 3000');
});

app.use('/api/admin',adminRoutes)

export default app;
